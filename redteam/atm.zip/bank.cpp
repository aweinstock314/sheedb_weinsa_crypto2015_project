#include <arpa/inet.h>
#include <fstream>
#include <iostream>
#include <map>
#include <netdb.h>
#include <netinet/in.h>
#include <pthread.h>
#include <sstream>
#include <stdio.h>
#include <string>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <vector>
#include <errno.h>
#include <stdlib.h>
#include <mutex>

#include <cryptopp/rsa.h>
#include <cryptopp/osrng.h>
#include <cryptopp/base64.h>
#include <cryptopp/files.h>

#include "action.h"
#include "userAccount.h"

#define BUFFER_SIZE 128
#define HANDSHAKE_BUFFER_SIZE 512

std::mutex m;

struct client_info {
  int sockfd;
  CryptoPP::RSA::PrivateKey *privateKey;
  CryptoPP::RSA::PublicKey *publicKey;
};

std::map<std::string, UserAccount*> user_database;

void balance_bank(const action::Action& action);
void clean_up(const std::string& current_user);
action::Action construct_action(const std::string& user,
                                const std::vector<std::string> toks,
                                std::string& nonce);
void deposit(const action::Action& action);
void init_bank();

// Actions that come from the ATM.
action::Action balance_atm(const action::Action& action);
action::Action login(const action::Action& action);
action::Action logout(const action::Action& action);
action::Action transfer(const action::Action& action);
action::Action withdraw(const action::Action& action);


void balance_bank(const action::Action& action) {
  m.lock();

  if (user_database.count(action.recipient()) > 0) {
    std::cout << action.recipient() << "'s balance is "
              << user_database[action.recipient()]->balance() << std::endl;

    m.unlock();

    return;
  }

  m.unlock();

  std::cout << "Error: " << action.recipient() << " doesn't exist." << std::endl;
}


void deposit(const action::Action& action) {
  unsigned long amnt;
  try {
    amnt = action.amount_to_long();
  } catch (std::exception const& e) {
    std::cout << "Error: Bad amount." << std::endl;
  }

  m.lock();

  if (user_database.count(action.recipient()) > 0) {
    std::cout << "Deposited " << action.amount() << " cents into "
              << action.recipient() << "'s account and new balance is "
              << user_database[action.recipient()]->deposit(amnt)
              << " cents." << std::endl;

    m.unlock();

    return;
  }

  m.unlock();

  std::cout << "Error: " << action.recipient_ << " doesn't exist." << std::endl;
}


void init_bank() {
  m.lock();

  user_database["Alice"] = new UserAccount("Alice" , "012345", 10000);
  user_database["Bob"] = new UserAccount("Bob", "654321", 5000);
  user_database["Eve"] = new UserAccount("Eve", "123456", 0);

  m.unlock();
}


// Function to generate public and private keys for RSA
void gen_rsa_keys(CryptoPP::RSA::PrivateKey &privateKey,
                  CryptoPP::RSA::PublicKey &publicKey) {
  CryptoPP::AutoSeededRandomPool rng;

  CryptoPP::InvertibleRSAFunction params;
  params.GenerateRandomWithKeySize(rng, 3072);

  privateKey.AssignFrom(params);
  publicKey.AssignFrom(params);
}


void bank_aes_handshake(int client_fd,
                        CryptoPP::RSA::PrivateKey &privateKey,
                        CryptoPP::RSA::PublicKey &publicKey,
                        byte* aes_key,
                        byte* iv,
                        std::string& init_nonce) {
  CryptoPP::AutoSeededRandomPool rng;
  char buf[HANDSHAKE_BUFFER_SIZE];
  memset(buf, 0, HANDSHAKE_BUFFER_SIZE);

  CryptoPP::ByteQueue queue;
  publicKey.Save(queue);

  read(client_fd, buf, HANDSHAKE_BUFFER_SIZE); // Dummy read to clear the socket

  byte publicKeyBuffer[HANDSHAKE_BUFFER_SIZE];
  memset(publicKeyBuffer, 0, HANDSHAKE_BUFFER_SIZE);
  size_t size = queue.Get((byte*)&publicKeyBuffer, sizeof(publicKeyBuffer));

  // std::cout << publicKeyBuffer
  write(client_fd, publicKeyBuffer, size);

  // Read encrypted AES key
  int num_read = read(client_fd, buf, HANDSHAKE_BUFFER_SIZE);

  std::string cipher(buf, num_read), recovered;
  CryptoPP::RSAES_OAEP_SHA_Decryptor d(privateKey);
  CryptoPP::StringSource ss1(cipher, true,
      new CryptoPP::PK_DecryptorFilter(rng, d,
          new CryptoPP::StringSink(recovered)
     )
  );

  sprintf(buf, "DUMMY");
  write(client_fd, buf, 5); // Dummy write to finish proxy transaction

  sprintf(reinterpret_cast<char*>(aes_key), "%s", recovered.c_str());

  char tmp[HANDSHAKE_BUFFER_SIZE];
  strcpy(tmp, reinterpret_cast<char*>(aes_key));

  // Read the encrypted initialization vector
  char iv_buf[HANDSHAKE_BUFFER_SIZE];
  int iv_num_read = read(client_fd, iv_buf, HANDSHAKE_BUFFER_SIZE);

  std::string cipher2(iv_buf, iv_num_read);
  std::string recovered_iv;
  CryptoPP::RSAES_OAEP_SHA_Decryptor d2(privateKey);
  CryptoPP::StringSource ss2(cipher2, true,
      new CryptoPP::PK_DecryptorFilter(rng, d2,
          new CryptoPP::StringSink(recovered_iv)
     )
  );

  sprintf(reinterpret_cast<char*>(iv), "%s", recovered_iv.c_str());
  strcpy(reinterpret_cast<char*>(aes_key), tmp);

  write(client_fd, buf, 5); // Dummy write to finish proxy transaction

  // Read in the encrypted nonce
  char nonce_buf[HANDSHAKE_BUFFER_SIZE];
  read(client_fd, nonce_buf, HANDSHAKE_BUFFER_SIZE);

  init_nonce = action::decrypt_aes(std::string(nonce_buf), aes_key, iv);

  write(client_fd, buf, 5); // Dummy write to finish proxy transaction
}


// Create an Action struct from the tokenized input. If the input is malformed,
// return a struct with action_type Malformed.
action::Action construct_action(const std::string& user,
                                const std::vector<std::string> toks,
                                std::string& nonce) {
  switch (action::map_input(toks[0])) {
    case action::Unknown:
      return action::Action(user, std::string(), std::string(), std::string(),
                            "unknown", std::string(), std::string());
    case action::Balance:
      if (toks.size() == 2)
        return action::Action(user, std::string(), std::string(), std::string(),
                              "balance", std::string(), toks[1]);
      break;
    case action::Deposit:
      if (toks.size() == 3) {
        return action::Action(user, std::string(), std::string(), std::string(),
                              "deposit", toks[2], toks[1]);
      }
      break;
    default:
      return action::Action(user, std::string(), std::string(), std::string(),
                            "malformed", std::string(), std::string());
  }
  return action::Action(user, std::string(), std::string(), std::string(),
                            "malformed", std::string(), std::string());
}

action::Action balance_atm(const action::Action& action) {
  action::Action a;

  m.lock();

  if (user_database.find(action.user()) != user_database.end()) {
    a.user_ = action.user();
    a.set_command("balance");
    a.amount_ = user_database[action.user()] -> printable_balance();

    m.unlock();

    return a;
  }

  m.unlock();

  a.user_ = action.user();
  a.set_command("malformed");
  return a;
}

action::Action login(const action::Action& action) {
  action::Action a;

  m.lock();

  if (user_database.find(action.user()) != user_database.end()) {
    if (user_database[action.user()] -> login(action.pin_)) {
      a.user_ = action.user();
      a.set_command("login");

      m.unlock();

      return a;
    }
  }

  m.unlock();

  a.set_command("malformed");
  return a;
}

action::Action logout(const action::Action& action) {
  action::Action a;

  m.lock();

  if (user_database.find(action.user()) != user_database.end()) {
    if (user_database[action.user()] -> logout()) {
      a.user_ = action.user();
      a.set_command("logout");

      m.unlock();

      return a;
    }
  }

  m.unlock();

  a.set_command("malformed");
  return a;
}

action::Action transfer(const action::Action& action) {
  action::Action a;

  m.lock();

  if (user_database.find(action.user()) != user_database.end() &&
      user_database.find(action.recipient()) != user_database.end()) {
    if ((user_database[action.user()] -> transfer(strtoul(action.amount().c_str(), NULL, 10), *(user_database[action.recipient()])))) {
      a.user_ = action.user();
      a.recipient_ = action.recipient();
      a.amount_ = user_database[action.user()] -> printable_balance();
      a.set_command("transfer");

      m.unlock();

      return a;
    }
  }

  m.unlock();

  a.set_command("malformed");
  return a;
}

action::Action withdraw(const action::Action& action) {
  action::Action a;

  m.lock();

  if (user_database.find(action.user()) != user_database.end()) {
    if ((user_database[action.user()] -> withdraw(strtoul(action.amount().c_str(), NULL, 10))) >= 0) {
      a.user_ = action.user();
      a.amount_ = user_database[action.user()] -> printable_balance();
      a.set_command("withdraw");

      m.unlock();

      return a;
    }
  }

  m.unlock();

  a.set_command("malformed");
  return a;
}

// Handler for incoming ATM connections.
void *thread_handle(void *args) {
  client_info *client_args = (client_info *) args;
  int client_sock = client_args -> sockfd;
  CryptoPP::RSA::PrivateKey *privateKey = client_args -> privateKey;
  CryptoPP::RSA::PublicKey *publicKey = client_args -> publicKey;

  byte aes_key[CryptoPP::AES::DEFAULT_KEYLENGTH];
  int dummy_alloc;
  byte iv[CryptoPP::AES::BLOCKSIZE];

  std::string nonce;
  bank_aes_handshake(client_sock, *privateKey, *publicKey, aes_key, iv, nonce);

  char buffer[BUFFER_SIZE];
  while (true) {
    // memset(buffer, 0, BUFFER_SIZE);
    // size_t num_read = read(client_sock, buffer, BUFFER_SIZE);
    std::string s;
    action::Action action = action::Action::recv(client_sock, s, aes_key, iv);
    action::Action response;

    if (action.old_nonce_ == nonce) {
      switch (action.atype()) {
        case action::Balance:
          response = balance_atm(action);
          break;
        case action::Login:
          response = login(action);
          break;
        case action::Logout:
          response = logout(action);
          break;
        case action::Transfer:
          response = transfer(action);
          break;
        case action::Withdraw:
          response = withdraw(action);
          break;
        case action::Malformed:
        default:
          std::cout << "These shouldn't happen." << std::endl;
          break;
      }

      nonce = action::generate_nonce();
      response.new_nonce_ = nonce;
      response.old_nonce_ = action.new_nonce_;

      response.send(client_sock, aes_key, iv);
    }
    // write(client_sock, buffer, num_read);
  }
  close(client_sock);
}

// Function to handle the console thread
void *console_handle(void *args) {
  action::Action action;

  while (true) {
    std::string dummy_nonce;
    action = action::handle_input(std::string(), construct_action, dummy_nonce);
    switch (action.atype_) {
      case action::Balance:
        balance_bank(action);
        break;
      case action::Deposit:
        deposit(action);
        break;
      case action::Malformed:
        std::cout << "Malformed input" << std::endl;
        break;
      default:
        std::cout << "Unknown action" << std::endl;
        break;
    }
  }
}


int main(int argc, char* argv[]) {
  // Command line arg parsing
  if (argc != 2) {
    std::cout<< "bad usage" << std::endl;
    exit(1);
  }
  std::string inputPort = argv[1];
  for (const char& c : inputPort) {
    if (!isdigit(c))
      throw std::exception();
  }
  unsigned int port = std::stoi(inputPort);
  init_bank();

  // Generate the public and private RSA keys
  CryptoPP::RSA::PrivateKey privateKey;
  CryptoPP::RSA::PublicKey publicKey;
  gen_rsa_keys(privateKey, publicKey);

  // Start up the console thread
  pthread_t console_thread;
  pthread_create(&console_thread, NULL, console_handle, NULL);

  // Set up the listening socket for the bank
  struct addrinfo hints, *res;
  int listen_sock;

  memset(&hints, 0, sizeof hints);
  hints.ai_family = AF_INET;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_flags = AI_PASSIVE;

  char port_str[10];
  sprintf(port_str, "%d", port);
  getaddrinfo(NULL, port_str, &hints, &res);

  listen_sock = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
  if (!listen_sock) {
    std::cerr << "Error: Bank listening socket creation failed" << std::endl;
    exit(1);
  }

  // Bind the listening socket and listen for incoming connections
  if (0 != bind(listen_sock, res->ai_addr, res->ai_addrlen)) {
    std::cerr << "Error: Bank listening socket bind failed" << std::endl;
    exit(1);
  }

  if (0 != listen(listen_sock, SOMAXCONN)) {
    std::cerr << "Error: Bank listening socket listen failed" << std::endl;
    exit(1);
  }

  while (true) {
    // Accept incoming client connections and spawn threads as necessary
    struct sockaddr_storage client;
    socklen_t addr_size;
    int client_sock;

    addr_size = sizeof client;
    client_sock = accept(listen_sock, (struct sockaddr *)&client, &addr_size);
    if (client_sock < 0) {
      std::cerr << "Client was not accepted (" << strerror(errno) << "). Continuing..." << std::endl;
      continue;
    }

    pthread_t client_thread;
    client_info client_args;
    client_args.sockfd = client_sock;
    client_args.privateKey = &privateKey;
    client_args.publicKey = &publicKey;

    int err = pthread_create(&client_thread, NULL, thread_handle, &client_args);
    if (0 != err) {
      std::cerr << "Error: Client thread could not be created (" << strerror(err) << ")" << std::endl;
      exit(1);
    }
  }

  return 0;
}