#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <string.h>
#include <fstream>
#include <unistd.h>
#include <errno.h>

#include <cryptopp/rsa.h>
#include <cryptopp/osrng.h>
#include <cryptopp/base64.h>
#include <cryptopp/files.h>

#include "action.h"

#define AES_KEY_LENGTH 16
#define BUFFER_SIZE 1024
#define HANDSHAKE_BUFFER_SIZE 512


byte aes_key[CryptoPP::AES::DEFAULT_KEYLENGTH+1];
byte iv[CryptoPP::AES::BLOCKSIZE+1];


void balance(const action::Action& action, int sock_fd, std::string& nonce);
action::Action construct_action(const std::string& user,
                                const std::vector<std::string> toks);
void login(action::Action& action, int sock_fd, std::string& nonce);
void logout(const action::Action& action, int sock_fd, std::string& current_user, std::string& nonce);
void transfer(const action::Action& action, int sock_fd, std::string& nonce);
void withdraw(const action::Action& action, int sock_fd, std::string& nonce);
bool verify_user_card(const std::string& username);


void login(action::Action& action, int sock_fd, std::string& current_user, std::string& nonce) {
  if (!verify_user_card(action.user())) {
    std::cout << "Error: Card for user " << action.user() << " does not exist." << std::endl;
    return;
  }
  std::cout << "Enter PIN:" << std::endl;
  std::string pin_str;
  std::getline(std::cin, pin_str);
  if (!action.set_pin(pin_str)) {
    std::cout << "Bad pin" << std::endl;
    return;
  }

  std::string s;
  action.send(sock_fd, aes_key, iv);
  action::Action response = action::Action::recv(sock_fd, s, aes_key, iv);

  if (response.old_nonce_ != action.new_nonce_ ||
      response.atype() == action::Malformed ||
      response.user() != action.user()) {
    std::cout << "Error: Login unsuccessful." << std::endl;
  } else {
    std::cout << "You've successfully logged in. Welcome " << response.user()
              << std::endl;
    current_user = response.user();
  }
  nonce = response.new_nonce_;
}


bool verify_user_card(const std::string& username) {
  std::string cardname = "cards/" + username + ".card";
  struct stat buffer;
  return (stat (cardname.c_str(), &buffer) == 0);
}


void logout(const action::Action& action, int sock_fd, std::string& current_user, std::string& nonce) {
  std::string s;
  action.send(sock_fd, aes_key, iv);
  action::Action response = action::Action::recv(sock_fd, s, aes_key, iv);

  if (response.old_nonce_ != action.new_nonce_ ||
      response.atype() == action::Malformed ||
      response.user() != action.user()) {
    std::cout << "Error: Logout unsuccessful." << std::endl;
  } else {
    std::cout << action.user() << " has logged out." << std::endl;
    current_user = "none";
  }
  nonce = response.new_nonce_;
}


void balance(const action::Action& action, int sock_fd, std::string& nonce) {
  std::string s;
  action.send(sock_fd, aes_key, iv);
  action::Action response = action.recv(sock_fd, s, aes_key, iv);

  if (response.old_nonce_ != action.new_nonce_ ||
      action.atype() == action::Malformed) {
    std::cout << "Error: Balance check was unsuccessful." << std::endl;
  } else {
    std::cout << "Your balance is " << response.amount() << " cents." << std::endl;
  }
  nonce = response.new_nonce_;
}


void withdraw(const action::Action& action, int sock_fd, std::string& nonce) {
  std::string s;
  action.send(sock_fd, aes_key, iv);
  action::Action response = action.recv(sock_fd, s, aes_key, iv);
  if (response.old_nonce_ != action.new_nonce_ ||
      response.atype() == action::Malformed) {
    std::cout << "Error: Withdrawal unsuccessful." << std::endl;
  } else {
    std::cout << "You withdrew " << action.amount() << " cents and your balance"
              << " is now " << response.amount() << " cents." << std::endl;
  }
  nonce = response.new_nonce_;
}


void transfer(const action::Action& action, int sock_fd, std::string& nonce) {
  std::string s;
  action.send(sock_fd, aes_key, iv);
  action::Action response = action.recv(sock_fd, s, aes_key, iv);
  if (response.old_nonce_ != action.new_nonce_ ||
      response.atype() == action::Malformed) {
    std::cout << "Error: Transfer unsuccessful." << std::endl;
  } else {
    std::cout << "You transferred " << action.amount() << " cents to "
              << response.recipient()<< " and your balance is now " << response.amount()
              << " cents." << std::endl;
  }
  nonce = response.new_nonce_;
}


void atm_aes_handshake(int sock_fd, std::string& nonce) {
  CryptoPP::AutoSeededRandomPool rng;
  char buf[HANDSHAKE_BUFFER_SIZE];
  memset(buf, 0, HANDSHAKE_BUFFER_SIZE);

  // Send AES key
  sprintf(buf, "DUMMY");
  write(sock_fd, buf, 5); // Dummy write to trigger proxy read

  // Get the bank's public key
  int num_read = read(sock_fd, buf, HANDSHAKE_BUFFER_SIZE);

  CryptoPP::RSA::PublicKey loadkey;
  CryptoPP::ByteQueue queue;

  queue.Put2((byte *)buf, num_read, 0, true);
  loadkey.Load(queue);

  std::string aes_str(reinterpret_cast<char*>(aes_key), CryptoPP::AES::DEFAULT_KEYLENGTH);
  std::string encrypted;
  CryptoPP::RSAES_OAEP_SHA_Encryptor e(loadkey);

  CryptoPP::StringSource ss1(aes_str, true,
      new CryptoPP::PK_EncryptorFilter(rng, e,
          new CryptoPP::StringSink(encrypted)
     )
  );

  write(sock_fd, encrypted.c_str(), encrypted.length());

  read(sock_fd, buf, HANDSHAKE_BUFFER_SIZE); // Dummy read to finish proxy transaction

  // Send initialization vector
  std::string iv_encrypted;
  std::string iv_str(reinterpret_cast<char*>(iv), CryptoPP::AES::BLOCKSIZE);
  CryptoPP::RSAES_OAEP_SHA_Encryptor e2(loadkey);
  CryptoPP::StringSource ss2(iv_str, true,
      new CryptoPP::PK_EncryptorFilter(rng, e2,
          new CryptoPP::StringSink(iv_encrypted)
     )
  );

  write(sock_fd, iv_encrypted.c_str(), iv_encrypted.length());

  read(sock_fd, buf, HANDSHAKE_BUFFER_SIZE); // Dummy read to finish proxy transaction

  // Send initial nonce
  nonce = action::generate_nonce();
  std::string encrypted_nonce = action::encrypt_aes(nonce, aes_key, iv);
  write(sock_fd, encrypted_nonce.c_str(), encrypted_nonce.length());

  read(sock_fd, buf, HANDSHAKE_BUFFER_SIZE); // Dummy read to finish proxy transaction
}

// Create an Action struct from the tokenized input. If the input is malformed,
// return a struct with action_type Malformed.
action::Action construct_action(const std::string& user,
                                const std::vector<std::string> toks,
                                std::string& nonce) {
  std::string new_nonce = action::generate_nonce();

  action::Action return_action(user, std::string(), nonce, new_nonce,
                               "malformed", std::string(), std::string());

  switch (action::map_input(toks[0])) {
    case action::Unknown:
    case action::Deposit:
      return_action.set_command("unknown");
      return return_action;
    case action::Balance:
      if (toks.size() == 1) {
        return_action.set_command("balance");
        return return_action;
      }
      break;
    case action::Login:
      if (toks.size() == 2) {
        return_action.set_command("login");
        return_action.user_ = toks[1];
        return return_action;
      }
      break;
    case action::Logout:
      if (toks.size() == 1) {
        return_action.set_command("logout");
        return return_action;
      }
      break;
    case action::Transfer:
      if (toks.size() == 3) {
        return_action.set_command("transfer");
        return_action.amount_ = toks[1];
        return_action.recipient_ = toks[2];
        return return_action;
      }
      break;
    case action::Withdraw:
      if (toks.size() == 2) {
        return_action.set_command("withdraw");
        return_action.amount_ = toks[1];
        return return_action;
      }
      break;
    default:
      return return_action;
  }
  nonce = std::string(new_nonce);
  return return_action;
}


int main(int argc, char* argv[]) {
  if (argc != 2) {
    std::cout << "bad usage" << std::endl;
    exit(1);
  }
  std::string inputPort = argv[1];
  for (const char& c : inputPort) {
    if (!isdigit(c))
      throw std::exception();
  }
  unsigned int proxyPort = stoi(inputPort);

  int sock_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if (!sock_fd) {
    std::cerr << "Error: ATM socket creation failed" << std::endl;
    exit(1);
  }

  struct sockaddr_in localhost;
  memset(&localhost, 0, sizeof(struct sockaddr_in));
  localhost.sin_family = AF_INET;
  localhost.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  localhost.sin_port = htons(proxyPort);

  if (0 != connect(sock_fd, (struct sockaddr*)&localhost, sizeof(localhost))) {
    std::cerr << "Error: Proxy connection failed (" << strerror(errno) << ")" << std::endl;
    close(sock_fd);
    exit(1);
  }

  action::Action in_action;
  std::string current_user = "none";
  std::string nonce;

  CryptoPP::AutoSeededRandomPool rng;
  rng.GenerateBlock(aes_key, CryptoPP::AES::DEFAULT_KEYLENGTH);
  rng.GenerateBlock(iv, CryptoPP::AES::BLOCKSIZE);
  atm_aes_handshake(sock_fd, nonce);

  while (true) {
    in_action = action::handle_input(current_user, construct_action, nonce);

    switch (in_action.atype()) {
      case action::Balance:
        if (current_user != "none")
          balance(in_action, sock_fd, nonce);
        else
          std::cout << "Please log in." << std::endl;
        break;
      case action::Login:
        if (current_user == "none")
          login(in_action, sock_fd, current_user, nonce);
        else
          std::cout << current_user << " is already logged in" << std::endl;
        break;
      case action::Logout:
        if (current_user != "none")
          logout(in_action, sock_fd, current_user, nonce);
        else
          std::cout << "Please log in." << std::endl;
        break;
      case action::Transfer:
        if (current_user != "none")
          transfer(in_action, sock_fd, nonce);
        else
          std::cout << "Please log in." << std::endl;
        break;
      case action::Withdraw:
        if (current_user != "none")
          withdraw(in_action, sock_fd, nonce);
        else
          std::cout << "Please log in." << std::endl;
        break;
      case action::Malformed:
        std::cout << "Invalid input" << std::endl;
        break;
      default:
        std::cout << "Unknown action" << std::endl;
        break;
    }
  }

  return 0;
}