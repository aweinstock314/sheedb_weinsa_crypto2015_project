#ifndef __USERACCOUNT_H_
#define __USERACCOUNT_H_

#include <iostream>
#include <string>
#include <vector>

class UserAccount {
public:
	UserAccount(std::string username, std::string pin, unsigned long balance)
		: username_(username)
		, pin_(pin)
		, balance_(balance)
		, login_(false) { }

	bool login(std::string inputPin);
	bool logout();
	std::string& username() { return username_; }
	unsigned long balance() const { return balance_; }
	std::string printable_balance();
	bool verifyWithdrawal(unsigned long amount);
	long withdraw(unsigned long amount);
	unsigned long deposit(unsigned long amount);
	bool transfer(unsigned long amount, UserAccount& recipient);

private:
	std::string username_;
	std::string pin_;
	unsigned long balance_;
	bool login_;
};

#endif