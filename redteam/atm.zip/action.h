#ifndef __ACTION_H__
#define __ACTION_H__

#include <iostream>
#include <math.h>
#include <sstream>
#include <string>
#include <time.h>
#include <vector>
#include <chrono>

#include <cryptopp/modes.h>
#include <cryptopp/aes.h>
#include <cryptopp/osrng.h>
#include <cryptopp/base64.h>
#include <cryptopp/files.h>
#include <cryptopp/filters.h>

#define ACTION_BUFFER_SIZE 128

namespace action {

typedef enum {
  Balance, Deposit, Login, Logout, Malformed, Transfer, Unknown, Withdraw
} action_type;

// username::pin::old_nonce::new_nonce::command::amount::recipient
class Action {
 public:
  std::string user_;
  std::string user() const { return user_; }
  std::string pin_;
  std::string old_nonce_;
  std::string new_nonce_;
  std::string command_;
  std::string command() const { return command_; }
  void set_command(std::string command);
  std::string amount_;
  std::string amount() const { return amount_; };
  std::string recipient_;
  std::string recipient() const { return recipient_; };

  action_type atype_;
  action_type atype() const { return atype_; }

  Action(std::string user, std::string pin, std::string old_nonce,
         std::string new_nonce, std::string cmd, std::string amnt,
         std::string recipient);
  Action();

  bool are_inputs_valid();
  static Action deserialize(std::string serial);
  static Action recv(int sock_fd, std::string& out_string, byte* key, byte* iv);
  void send(int sock_fd, byte* key, byte* iv) const;
  std::string serialize() const;
  bool set_amount(std::string amnt);
  bool set_pin(std::string pin);
  unsigned long amount_to_long() const;
};


std::string generate_garbage(int sz);
std::string generate_nonce();
Action handle_input(const std::string& user);
bool is_amount_valid(const std::string& amnt);
bool is_pin_valid(const std::string& pin);
action_type map_input(const std::string& input);
std::string map_atype(int a);
std::vector<std::string> split(const std::string &s, char delim);
std::string encrypt_aes(const std::string& p, byte* key, byte* iv);
std::string decrypt_aes(const std::string& e, byte* key, byte* iv);

Action::Action(std::string user, std::string pin, std::string old_nonce,
               std::string new_nonce, std::string cmd, std::string amnt,
               std::string recipient)
  : user_(user), old_nonce_(old_nonce), new_nonce_(new_nonce), command_(cmd),
    recipient_(recipient) {
  atype_ = map_input(command_);
  if (!set_pin(pin) || !set_amount(amnt)) {
    user_ = std::string();
    pin_ = std::string();
    old_nonce_ = std::string();
    new_nonce = std::string();
    command_ = std::string();
    amount_ = std::string();
    recipient_ = std::string();
    atype_ = Malformed;
  }
}

Action::Action() {
  Action(std::string(), std::string(), std::string(), std::string(),
         "malformed", std::string(), std::string());
}

void Action::set_command(std::string command) {
  command_ = command;
  atype_ = map_input(command);
}

//
//    16        16        n      10*    6*     1      11*     10*      50-n
// old_nonce;new_nonce:garbage:username;pin;command;amount;recipient:garbage
std::string Action::serialize() const {
  char buffer[ACTION_BUFFER_SIZE];
  // 50 bytes of garbage.
  int g_size = ACTION_BUFFER_SIZE - (16 + 16 + user_.size() + pin_.size() + 1 +
                              amount_.size() + recipient_.size() + 8);
  int sz1 = 1;  // between 1 and 49
  int sz2 = g_size - sz1;  // between 1 and 49

  sprintf(buffer, "%s;%s:%s:%s;%s;%d;%s;%s:%s",
          old_nonce_.c_str(),
          new_nonce_.c_str(),
          generate_garbage(sz1).c_str(),
          user_.c_str(),
          pin_.c_str(),
          atype_,
          amount_.c_str(),
          recipient_.c_str(),
          generate_garbage(sz2).c_str());

  return std::string(buffer);
}

void Action::send(int sock_fd, byte* key, byte* iv) const {
  write(sock_fd, encrypt_aes(serialize(), key, iv).c_str(), ACTION_BUFFER_SIZE);
}

Action Action::deserialize(std::string serial) {
  std::vector<std::string> toks = split(serial, ':');
  if (toks.size() != 4)
    return Action();
  std::vector<std::string> nonces = split(toks[0], ';');
  std::vector<std::string> rest = split(toks[2], ';');
  if (nonces.size() != 2 || rest.size() != 5)
    return Action();
  // std::cout << "deserialize: " << serial << std::endl;
  // std::cout << "toks: " << toks.size() << " nonces: " << nonces.size()
  //           << " rest: " << rest.size() << std::endl;
  return Action(rest[0], rest[1], nonces[0], nonces[1], map_atype(stoi(rest[2])),
                rest[3], rest[4]);
}

Action Action::recv(int sock_fd, std::string& out_string, byte* key, byte* iv) {
  char buffer[ACTION_BUFFER_SIZE];
  int num_read = read(sock_fd, buffer, ACTION_BUFFER_SIZE);
  out_string = std::string(buffer);
  return deserialize(decrypt_aes(std::string(buffer, ACTION_BUFFER_SIZE), key, iv));
}

bool Action::set_pin(std::string pin) {
  if (pin == std::string())
    return true;
  if (!is_pin_valid(pin))
    return false;
  pin_ = pin;
  return true;
}

bool Action::set_amount(std::string amnt) {
  if (amnt == std::string())
    return true;
  if (!is_amount_valid(amnt))
    return false;
  amount_ = amnt;
  return true;
}

unsigned long Action::amount_to_long() const {
  if (!is_amount_valid(amount_))
    throw std::exception();
  return stoul(amount_, nullptr);
}


std::string generate_garbage(int sz) {
  unsigned int randint;
  CryptoPP::AutoSeededRandomPool rnd;
  std::string garbage;
  std::string anum = "0123456789!@#$^&*ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmn"
                     "opqrstuvwxyz";
  for (int i = 0; i < sz; ++i) {
    rnd.GenerateBlock( (byte*)&randint, sizeof( int ));
    garbage += anum[randint % anum.size()];
  }
  return garbage;
}


std::string generate_nonce() {
  long t = std::chrono::system_clock::now().time_since_epoch().count();
  char buffer[16];
  sprintf(buffer, "%s%ld", generate_garbage(8).c_str(), t%99999999);

  return std::string(buffer);
}


// Utility function for encrypting a string with AES
std::string encrypt_aes(const std::string& p, byte* key, byte* iv) {
  int message_len = p.length();
  char encrypted[message_len];
  CryptoPP::AutoSeededRandomPool rnd;
  CryptoPP::CFB_Mode<CryptoPP::AES>::Encryption cfbEncryption(key, 16, iv);
  cfbEncryption.ProcessData((byte*) encrypted, (byte*) p.c_str(), message_len);

  std::string result(encrypted, message_len);
  return result;
}


// Utility function for decrypting an AES-encrypted string
std::string decrypt_aes(const std::string& e, byte* key, byte* iv) {
  int message_len = e.length();
  char decrypted[message_len];
  CryptoPP::AutoSeededRandomPool rnd;
  CryptoPP::CFB_Mode<CryptoPP::AES>::Decryption cfbDecryption(key, 16, iv);
  cfbDecryption.ProcessData((byte*) decrypted, (byte*) e.c_str(), message_len);

  std::string result(decrypted, message_len);
  return result;
}


// Amount must be in cents and is capped at 999 999 999 cents
bool is_amount_valid(const std::string& amnt) {
  size_t sz;
  try {
    unsigned long amntl = stoul(amnt, &sz);
    if (amntl > 999999999)
      throw std::exception();
  } catch (std::exception const& e) {
    return false;
  }
  return amnt.size() == sz;
}


bool is_pin_valid(const std::string& pin) {
  size_t sz;
  try {
    if (pin.size() > 6 || pin.size() < 4)
      throw std::exception();
    stoi(pin, &sz);
  } catch (std::exception const& e) {
    return false;
  }
  return pin.size() == sz;
}


// Parse the input and form it into an Action struct.
Action handle_input(const std::string& user,
    Action (*construct_action)(const std::string&, std::vector<std::string>, std::string&),
    std::string& nonce) {
  std::string input;
  std::getline(std::cin, input);
  std::vector<std::string> toks = split(input, ' ');

  if (toks.size() <= 0)
    return action::Action(user, std::string(), std::string(), std::string(),
                          "malformed", std::string(), std::string());
  return construct_action(user, toks, nonce);
}


// Map the input action to an action_type enum. This is useful for switching on
// the action.
action_type map_input(const std::string& input) {
  if (input == "balance") {
    return Balance;
  } else if (input == "deposit") {
    return Deposit;
  } else if (input == "login") {
    return Login;
  } else if (input == "logout") {
    return Logout;
  } else if (input == "transfer") {
    return Transfer;
  } else if (input == "withdraw") {
    return Withdraw;
  } else if (input == "unknown") {
    return Unknown;
  }
  return Malformed;
}


std::string map_atype(int a) {
  switch(a) {
    case 0:
      return "balance";
    case 1:
      return "deposit";
    case 2:
      return "login";
    case 3:
      return "logout";
    case 4:
      return "malformed";
    case 5:
      return "transfer";
    case 6:
      return "unknown";
    case 7:
      return "withdraw";
    default:
      return "malformed";
  }
}


// Split a string on |delim| characters.
std::vector<std::string> split(const std::string &s, char delim) {
  std::vector<std::string> tokens;
  int start = 0, end = 0;
  while ((end = s.find(delim, start)) != std::string::npos) {
    tokens.push_back(s.substr(start, end - start));
    start = end + 1;
  }
  tokens.push_back(s.substr(start));
  return tokens;
}


} // End namespace action

#endif