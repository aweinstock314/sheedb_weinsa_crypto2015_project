#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <arpa/inet.h>

#define BACKLOG_SIZE 4096
#define BUFFER_SIZE 1024

//------------------------------------------------------------------------------
// Set up the listening socket port
//------------------------------------------------------------------------------
int server_listen(int port=9000) {
  // Set up structures to store the connection information
  struct addrinfo hints, *res;
  int listen_sock;

  // Clear the hints struct and set the relevant parameters
  memset(&hints, 0, sizeof hints);
  hints.ai_family = AF_INET;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_flags = AI_PASSIVE;

  // Get the address info of the port from the hints struct and
  //  store the results in the res struct
  char port_str[10];
  sprintf(port_str, "%d", port);
  getaddrinfo(NULL, port_str, &hints, &res);

  // Set up the listening socket
  listen_sock = socket(res->ai_family, res->ai_socktype, res->ai_protocol);

  // Bind the listening socket
  bind(listen_sock, res->ai_addr, res->ai_addrlen);

  // Listen for incoming connections on the bound socke
  listen(listen_sock, BACKLOG_SIZE);

  // Return the file descriptor for the listening socket
  return listen_sock;
}

//------------------------------------------------------------------------------
// Accept a client connection on the listening port
//------------------------------------------------------------------------------
int accept_client(int listen_sock, struct sockaddr *client_addr) {
  // Set up the structures to store the client address information
  struct sockaddr_storage client;
  socklen_t addr_size;
  int client_sock;

  // Accept a client connection on the listening socket, storing the addres
  //  in the client struct
  addr_size = sizeof client;
  client_sock = accept(listen_sock, (struct sockaddr *)&client, &addr_size);

  // Set the inputted client address pointer to reference the client struct
  //  to send the client address information out of the function
  client_addr = (struct sockaddr *)&client;

  // Return the file descriptor for the new client socket
  return client_sock;
}

//------------------------------------------------------------------------------
// Receive data from the input file descriptor socket stream and store it into
// the buffer
//------------------------------------------------------------------------------
int server_recv(int client_fd, void *buffer, unsigned int len, int flags) {
  // Set up the buffers and set up the number of bytes to be read
  unsigned int to_read = len;
  char* buf = (char *)buffer;

  // Read the input number of bytes
  while (to_read > 0) {
    std::cout << "About to receive some shit" << std::endl;
    int received = recv(client_fd, buf, to_read, flags);
    std::cout << buf << std::endl;
    if (received < 0)
      return received;

    to_read -= received;
    buf += received;
  }

  return (int)len;
}

//------------------------------------------------------------------------------
// C'mon you know what this does...
//------------------------------------------------------------------------------
int main() {
  // Set up the structure to store the client address information and start
  //  the listening server 
  int listen_fd = server_listen();

  // Accept a client connection (blocks here)
  struct sockaddr *client;
  int client_fd = accept_client(listen_fd, client);

  // Print the IP address of the incoming client connection using the client
  //  address information (not sure if this is working right... -PK)
  struct sockaddr_in* addr;
  addr = (sockaddr_in*)((struct addrinfo *)client)->ai_addr;
  std::cout << inet_ntoa((struct in_addr)addr->sin_addr) << std::endl;
  std::cout << "Accepted client connection" << std::endl;

  // Try to receive the data
  char buffer[BUFFER_SIZE];
  memset(buffer, 0, BUFFER_SIZE);
  int num_recvd = server_recv(client_fd, buffer, BUFFER_SIZE, 0);
  std::cout << num_recvd << std::endl;
  std::cout << "Received some data" << std::endl;
  
  // Print the received data
  std::string read_string(buffer);
  std::cout << read_string << std::endl;
  
  return 0;
}
