# Crypto & Network Security ATM Protocol
#### Peter Kang
#### Kevin Andrade
#### Julius Alexander IV

Our group's Bank-ATM system uses RSA for key exchange and AES to encrypt
messages between the ATM and Bank. Two 3072-bit keys are used for the RSA key 
exchange to share the 128-bit AES key.

Every time a connection between a new ATM and the Bank is made, the Bank 
initially generates its RSA keys (public and private) for the key exchange, and
sends its public key to the ATM. Upon recieving this key, the ATM generates the
AES key which is encrypted with the Bank's public key. This encrypted key is
then sent to the Bank. The Bank then decrypts the encrypted AES key using its
private key and now the ATM and Bank both have the AES key.

The ATM card just stores the User's name. When a card is used at an ATM, 
the ATM prompts for the User to input their PIN. The value input along 
with the request (in this case login), and other parameters are then 
serialized before the whole serialized string is encrypted with AES. Once
encrypted, the ATM sends this block of serialized data to the proxy which then
sends it to the bank. Once received, the bank decrypts the blocks of data and
then deserializes them. The request is then carried out and the value 
associated with the request (either a true or false in regards to if the 
login succeeded, meaning the inputted PIN matches the PIN on the account 
in the bank’s database) is then serialized and encrypted before being 
sent back to the ATM. Finally, the information received from the bank is 
decrypted and deserialized before printing an appropriate statement (and 
terminating the connection depending on the command), after which the ATM waits
for another request and repeat the whole communication process again.

The command string serialization is in the following form as a 128-byte string:  
:old-nonce;new-nonce;garbage;user;pin;command;amount;recipient;garbage:
where
old-nonce = 16 bytes
new-nonce = 16 bytes
user = <= 10 bytes
pin = 4-6 bytes
command = 1 byte
amount = <= 9 bytes

The nonces are being used to authenticate that old commands will not be able to
be used in a replay attack as each time either the bank or the ATM 
receive a message they validate that the old nonce is the one they have stored 
and then reply with the nonce being expected and the one they will expect with 
the next message. If a nonce does not match, then the receiving party that is
looking for the matching nonce will continue to wait until it finds it.
However, it never will and the connection will hang indefinitely. This was
determined to be acceptable because it will at least ensure that information
isn't leaked. The garbage after the nonces and at the end of the 
serialization are being used to combat the vulnerabilities of block ciphers by 
changing where the blocks would break up the command string. The amount is to be
an integer in from 0 to 999999999 representing cents. No floats are allowed and
cents are the most precise (and only precision) that the protocol supports.

Input validation and things of that nature happen when a command is read on
both the ATM and Bank sides. This includes when a serialized string is received.
If a command is determined to be invalid, it is discarded and a reply is sent
saying the command was bad. If a command is determined to contain valid inputs,
only then will an attempt be made to execute it. This happens on the bank and is
where things such as verifying sufficient funds happens. Again, if this
verification fails, a response is sent saying so and the command is discarded.

The bank is multithreaded where there's one thread for the console and a thread
for each connection through the proxy to an ATM. There is one mutex that locks
the user database to prevent race conditions.