#include <iostream>
#include <pthread.h>
#include <sstream>
#include <string>
#include <vector>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <string.h>
#include <fstream>
#include <unistd.h>

#define BUFFER_SIZE 4096

struct client_info {
  int sockfd;
  unsigned int bank_port;
};

void *thread_handle(void *args) {
  client_info *atm_args = (client_info *) args;
  int atm_fd = atm_args -> sockfd;
  unsigned int bank_port = atm_args -> bank_port;

  int bank_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

  struct sockaddr_in localhost;
  memset(&localhost, 0, sizeof(struct sockaddr_in));
  localhost.sin_family = AF_INET;
  localhost.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  localhost.sin_port = htons(bank_port);

  connect(bank_fd, (struct sockaddr*)&localhost, sizeof(localhost));

  char buffer[BUFFER_SIZE];
  while (true) {
    memset(buffer, 0, BUFFER_SIZE);
    size_t num_read = read(atm_fd, buffer, BUFFER_SIZE);
    write(bank_fd, buffer, num_read);

    memset(buffer, 0, BUFFER_SIZE);
    num_read = read(bank_fd, buffer, BUFFER_SIZE);
    write(atm_fd, buffer, num_read);
  }
}

int main(int argc, char* argv[]) {
  if (argc != 3) {
    std::cout << "bad usage" << std::endl;
    exit(1);
  }

  std::string inputPort = argv[1];
  std::string inputPort2 = argv[2];

  for (const char& c : inputPort) {
    if (!isdigit(c))
      throw std::exception();
  }
  for (const char& c : inputPort2) {
    if (!isdigit(c))
      throw std::exception();
  }

  unsigned int listenPort = std::stoi(inputPort);
  unsigned int bankPort = std::stoi(inputPort2);

  struct addrinfo hints, *res;
  int listen_sock;

  memset(&hints, 0, sizeof hints);
  hints.ai_family = AF_INET;
  hints.ai_socktype = SOCK_STREAM;
  hints.ai_flags = AI_PASSIVE;

  char port_str[10];
  sprintf(port_str, "%d", listenPort);
  getaddrinfo(NULL, port_str, &hints, &res);

  listen_sock = socket(res->ai_family, res->ai_socktype, res->ai_protocol);

  bind(listen_sock, res->ai_addr, res->ai_addrlen);

  listen(listen_sock, SOMAXCONN);

  while (true) {
    struct sockaddr_storage client;
    socklen_t addr_size;
    int client_sock;

    addr_size = sizeof client;
    client_sock = accept(listen_sock, (struct sockaddr *)&client, &addr_size);

    pthread_t client_thread;
    client_info thread_args;
    thread_args.sockfd = client_sock;
    thread_args.bank_port = bankPort;

    pthread_create(&client_thread, NULL, thread_handle, &thread_args);
  }
}