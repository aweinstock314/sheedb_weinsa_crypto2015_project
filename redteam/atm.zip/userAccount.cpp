#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include "userAccount.h"

bool UserAccount::login(std::string inputPin) {
	if (inputPin == pin_ && !login_){
		login_ = true;
		return true;
	}
	return false;
}

bool UserAccount::logout() {
	if (login_) {
		login_ = false;
		return true;
	}
	return false;
}

std::string UserAccount::printable_balance() {
	return std::to_string(balance_);
}

bool UserAccount::verifyWithdrawal(unsigned long amount) {
	if(balance_ >= amount && amount >= 0)
		return true;
	return false;
}

long UserAccount::withdraw(unsigned long amount) {
	if(verifyWithdrawal(amount)){
		balance_ = balance_ - amount;
		return balance_;
	}
	return -1;
}

unsigned long UserAccount::deposit(unsigned long amount) {
	balance_ = balance_ + amount;
	return balance_;
}

bool UserAccount::transfer(unsigned long amount, UserAccount& recipient) {
	if(verifyWithdrawal(amount)){
		withdraw(amount);
		recipient.deposit(amount);
		return true;
	}
	return false;
}